Searchable Accordion Menu
-------------------------
This folder contains the implementation (incl components and configuration) of this frontend pattern.