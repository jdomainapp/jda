<template src="./layouts/header.html"></template>
<script>
  import "bootstrap/dist/js/bootstrap.bundle.js";
  import "bootstrap/js/dist/popover.js";
  import "bootstrap/dist/css/bootstrap.min.css";

  export default {
    name: 'App',
  }
</script>