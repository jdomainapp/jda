Auto Search
-------------------------
This folder contains the implementation (incl components and configuration) of this frontend pattern.