FeGen Example
