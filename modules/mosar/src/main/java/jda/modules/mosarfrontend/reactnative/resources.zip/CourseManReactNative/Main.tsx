import * as React from 'react';
import JDADrawer from './base/views/jda_drawer/JDADrawer';
import {
  StudentClass,
  Address,
  Student,
  Enrolment,
  CourseModule,
} from './modules/Modules';

export default class MainScreen extends React.Component {
  public render() {
    return (
      <JDADrawer
        initialRoute={'StudentClass'}
        routes={[
          {
            component: <StudentClass />,
            name: 'StudentClass',
          },
          {
            component: <Address />,
            name: 'Address',
          },
          {
            component: <Student />,
            name: 'Student',
          },
          {
            component: <Enrolment />,
            name: 'Enrolment',
          },
          {
            component: <CourseModule />,
            name: 'CourseModule',
          },
        ]}
      />
    );
  }
}
