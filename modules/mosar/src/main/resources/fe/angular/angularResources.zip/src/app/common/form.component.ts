export interface FormComponent {
    item: any;
    _item: any;
    search(search_id: any): void;
    delete(id: any): void;
  }
  