import { NativeStackScreenProps } from '@react-navigation/native-stack';
import _ from 'lodash';
import { useCallback } from 'react';
import { JDAFormMode } from '../jda_form_controllers/withFormController';
import { JDAModuleView } from '../jda_module_controller/hooks/useModuleHandler';
import { IRoute } from './withJDARouter';

type CreateRouteParam = {
    type: JDAModuleView.FORM,
    mode: JDAFormMode.CREATE
}
type EditRouteParam<T> = {
    type: JDAModuleView.FORM,
    mode: JDAFormMode.EDIT,
    item: T
}
type ViewRouteParam<T> = {
    type: JDAModuleView.FORM,
    mode: JDAFormMode.READ_ONLY,
    item: T
}
export type JDARouterParams<T> = CreateRouteParam | EditRouteParam<T> | ViewRouteParam<T>

export function useRouter<T>(props: NativeStackScreenProps<any>, routes: IRoute[]) {
    const RouteMap = _.chain(routes).keyBy('name').value();
    console.log(RouteMap);


    const goHome = useCallback(
        () => {
            props.navigation.popToTop()
        },
        [],
    );

    const goToModule = useCallback(
        (name: keyof typeof RouteMap) => {
            props.navigation.navigate(name)
        },
        [],
    );

    const openModuleCreateForm = useCallback(
        (name: keyof typeof RouteMap) => {
            const params: CreateRouteParam = {
                type: JDAModuleView.FORM,
                mode: JDAFormMode.CREATE
            }
            props.navigation.push(name, params)
        },
        [],
    );

    const openModuleEditForm = useCallback(
        (name: keyof typeof RouteMap, item: T) => {
            const params: EditRouteParam<T> = {
                type: JDAModuleView.FORM,
                mode: JDAFormMode.EDIT,
                item: item
            }
            props.navigation.push(name, params)
        },
        [],
    );
    const openModuleViewForm = useCallback(
        (name: keyof typeof RouteMap, item: T) => {
            const params: ViewRouteParam<T> = {
                type: JDAModuleView.FORM,
                mode: JDAFormMode.READ_ONLY,
                item: item
            }
            props.navigation.push(name, params)
        },
        [],
    );

    return {
        JDARouter: {
            goHome,
            goToModule,
            openModuleCreateForm,
            openModuleEditForm,
            openModuleViewForm
        }
    };
}
