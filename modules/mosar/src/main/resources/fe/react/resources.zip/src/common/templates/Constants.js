const constants =  {
  host: "http://localhost:{{ beServerPort }}"
};
export default constants;