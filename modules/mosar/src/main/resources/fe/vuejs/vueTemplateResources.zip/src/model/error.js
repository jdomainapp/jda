export default class Error {
    constructor(code, message) {
        this.code = code
        this.message = message
    }
}